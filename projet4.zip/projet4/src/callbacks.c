#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif

#include <gtk/gtk.h>

#include "callbacks.h"
#include "interface.h"
#include "support.h"
#include "fichier.h"

int x;
int y;
void
on_button6_clicked                     (GtkButton       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *window1,*window2;
window2=create_window2() ;
window1=lookup_widget(objet_graphique,"window1");
gtk_widget_hide(window1);
gtk_widget_show (window2);
}


void
on_button3_clicked                     (GtkButton       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *window1,*window4;
window4=create_window4() ;
window1=lookup_widget(objet_graphique,"window1");
gtk_widget_hide(window1);
gtk_widget_show (window4);
}


void
on_button1_clicked                     (GtkButton       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *window1,*window3;
window3=create_window3() ;
window1=lookup_widget(objet_graphique,"window1");
gtk_widget_hide(window1);
gtk_widget_show (window3);
}


void
on_button4_clicked                     (GtkButton       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *window1;
GtkWidget *treeview1;
window1=lookup_widget(objet_graphique,"window1");
treeview1=lookup_widget(window1,"treeview1");
afficher(treeview1);
}


void
on_button5_clicked                     (GtkButton       *objet_graphique,
                                        gpointer         user_data)
{
return 0;
}


void
on_button2_clicked                     (GtkButton       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *window1,*window6;
window6=create_window6() ;
window1=lookup_widget(objet_graphique,"window1");
gtk_widget_hide(window1);
gtk_widget_show (window6);
}


void
on_button21_clicked                    (GtkButton       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *window1,*window7;
window7=create_window7() ;
window1=lookup_widget(objet_graphique,"window1");
gtk_widget_hide(window1);
gtk_widget_show (window7);
}


void
on_button11_clicked                    (GtkButton       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget  *output,*input1 , *input2, *input3, *input4, *input5 , *input6;
GtkWidget *window2;
int x;
equip a;
char txt2[20]="neuf";
{if (x==1)
strcpy(txt2,"neuf");
else if (x==2) 
strcpy(txt2,"en_panne");}
window2=create_window2();
input1=lookup_widget(objet_graphique,"entry1");
input2=lookup_widget(objet_graphique,"entry2"); 
input3=lookup_widget(objet_graphique,"entry3"); 
input4=lookup_widget(objet_graphique,"entry4"); 
input5=lookup_widget(objet_graphique,"entry5"); 
output=lookup_widget(objet_graphique,"label22");
strcpy(a.nom,gtk_entry_get_text(GTK_ENTRY(input1))); 
strcpy(a.code_serie,gtk_entry_get_text(GTK_ENTRY(input2))); 
strcpy(a.emplacement,gtk_entry_get_text(GTK_ENTRY(input3)));
strcpy(a.date,gtk_entry_get_text(GTK_ENTRY(input4)));
strcpy(a.nd_panne,gtk_entry_get_text(GTK_ENTRY(input5)));
strcpy(a.etats,txt2);
if ((strcmp(a.nom,"")==0)||(strcmp(a.code_serie,"")==0)||(strcmp(a.emplacement,"")==0)||(strcmp(a.date,"")==0)||(strcmp(a.nd_panne,"")==0)||(strcmp(a.etats,"")==0))
{
 gtk_label_set_text(GTK_LABEL(output),"remplir tous les champs!");
}
else 
{
ajout(a);
gtk_label_set_text(GTK_LABEL(output),"l'equipement est ajouté avec succés");} 

}


void
on_button12_clicked                    (GtkButton       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *window1,*window2;
window1=create_window1() ;
window2=lookup_widget(objet_graphique,"window2");
gtk_widget_hide(window2);
gtk_widget_show (window1);
}


void
on_button16_clicked                    (GtkButton       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *input1, *output;
GtkWidget *window4, *window5;

char code[20];
int x;
input1=lookup_widget(objet_graphique,"entry8");
output=lookup_widget(objet_graphique,"label57");
strcpy(code,gtk_entry_get_text(GTK_ENTRY(input1))); 
x=rech(code);
if(x==1)
{
window5=create_window5();
gtk_widget_show(window5);
window4=lookup_widget(objet_graphique,"window4");
gtk_widget_hide(window4);
}
else if(x==0)
{gtk_label_set_text(GTK_LABEL(output),"l'equipement non existant");}

}


void
on_button15_clicked                    (GtkButton       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *window1,*window4;
window1=create_window1() ;
window4=lookup_widget(objet_graphique,"window4");
gtk_widget_hide(window4);
gtk_widget_show (window1);
}


void
on_button18_clicked                    (GtkButton       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *output, *input1 , *input2, *input3, *input4, *input5, *input6;
GtkWidget *window5;
equip a;
char code[20];
char txt1[20]="neuf";
{if (y==1)
strcpy(txt1,"neuf");
if (y==2)
strcpy(txt1,"en_panne");}
window5=create_window5();
input1=lookup_widget(objet_graphique,"entry9");
input2=lookup_widget(objet_graphique,"entry10"); 
input3=lookup_widget(objet_graphique,"entry11"); 
input4=lookup_widget(objet_graphique,"entry12"); 
input5=lookup_widget(objet_graphique,"entry13"); 
//input6=lookup_widget(objet_graphique,"entry14");
output=lookup_widget(objet_graphique,"label55");
strcpy(a.nom,gtk_entry_get_text(GTK_ENTRY(input1))); 
strcpy(a.code_serie,gtk_entry_get_text(GTK_ENTRY(input2))); 
strcpy(a.emplacement,gtk_entry_get_text(GTK_ENTRY(input3)));
strcpy(a.date,gtk_entry_get_text(GTK_ENTRY(input4)));
strcpy(a.nd_panne,gtk_entry_get_text(GTK_ENTRY(input5)));
strcpy(a.etats,txt1);
modifier(a);
gtk_label_set_text(GTK_LABEL(output),"l'equipement est modifié avec succés");
}


void
on_button17_clicked                    (GtkButton       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *window1,*window5;
window1=create_window1() ;
window5=lookup_widget(objet_graphique,"window5");
gtk_widget_hide(window5);
gtk_widget_show (window1);
}


void
on_button19_clicked                    (GtkButton       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *input1, *output,*output1,*output2,*output3,*output4,*output5,*output6;
GtkWidget *window6;
window6=create_window6();
char code[20];
int x;
equip a;
input1=lookup_widget(objet_graphique,"entry15");
strcpy(code,gtk_entry_get_text(GTK_ENTRY(input1))); 
output=lookup_widget(objet_graphique,"label39");
x=rech(code);

if(x==1)
{

gtk_label_set_text(GTK_LABEL(output),"l'equipement existe");
}
else 
{
gtk_label_set_text(GTK_LABEL(output),"l'equipement inexistant");
}
}

void
on_button20_clicked                    (GtkButton       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *window1,*window6;
window1=create_window1() ;
window6=lookup_widget(objet_graphique,"window6");
gtk_widget_hide(window6);
gtk_widget_show (window1);
}


void
on_button14_clicked                    (GtkButton       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *window1,*window3;
window1=create_window1() ;
window3=lookup_widget(objet_graphique,"window3");
gtk_widget_hide(window3);
gtk_widget_show (window1);
}


void
on_button13_clicked                    (GtkButton       *objet_graphique,
                                        gpointer         user_data)
{
/*GtkWidget *input1, *output;
GtkWidget *window3;
window3=create_window3();
char code[20];
int x;
input1=lookup_widget(objet_graphique,"entry7");
strcpy(code,gtk_entry_get_text(GTK_ENTRY(input1))); 
output=lookup_widget(objet_graphique,"label21");
x=rech(code);
if(x==1)
{
supp(code);
gtk_label_set_text(GTK_LABEL(output),"l'equipement est supprimé avec succés");
}
else 
{
gtk_label_set_text(GTK_LABEL(output),"l'equipement inexistant");
}*/
char code_serie[20];
GtkWidget *Combobox3,*output;
Combobox3 = lookup_widget(objet_graphique,"combobox3");
output=lookup_widget(objet_graphique,"label21");
if(gtk_combo_box_get_active_text(GTK_COMBO_BOX(Combobox3))!= NULL)
	{
	strcpy(code_serie, gtk_combo_box_get_active_text(GTK_COMBO_BOX(Combobox3)));
	supp(code_serie);
	gtk_label_set_text(GTK_LABEL(output),"l'equipement est supprimé avec succés");}
}


void
on_button22_clicked                    (GtkButton       *objet_graphique,
                                        gpointer         user_data)
{
int n,i;
char code[50][50];
GtkWidget *Combobox3;
Combobox3=lookup_widget(objet_graphique,"combobox3");
n=combo2(code); 

for(i=0;i<n;i++)
{
gtk_combo_box_append_text(GTK_COMBO_BOX(Combobox3),_(code[i]));
}
}




void
on_button23_clicked                    (GtkButton       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *window1,*window7;
window1=create_window1() ;
window7=lookup_widget(objet_graphique,"window7");
gtk_widget_hide(window7);
gtk_widget_show (window1);
}


void
on_button27_clicked                    (GtkButton       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *input1,*output;
GtkWidget *window5;
GtkWidget *entry9;
GtkWidget *entry10;
GtkWidget *entry11;
GtkWidget *entry12;
GtkWidget *entry13;
GtkWidget *entry14;
GtkWidget *entry15;
equip a ;
FILE* f ;
char code[20];
int x;
window5=create_window5();
input1=lookup_widget(objet_graphique,"entry16");
entry10=lookup_widget(objet_graphique,"entry9");
entry11=lookup_widget(objet_graphique,"entry10");
entry12=lookup_widget(objet_graphique,"entry11");
entry13=lookup_widget(objet_graphique,"entry12");
entry14=lookup_widget(objet_graphique,"entry13");
entry15=lookup_widget(objet_graphique,"entry14");
output=lookup_widget(objet_graphique,"label55");
strcpy(code,gtk_entry_get_text(GTK_ENTRY(input1)));

x=rech(code);
if(x==1)
{
a=rechercher(code);
gtk_entry_set_text(GTK_ENTRY(entry10),a.nom);
gtk_entry_set_text(GTK_ENTRY(entry11),a.code_serie);
gtk_entry_set_text(GTK_ENTRY(entry12),a.emplacement);
gtk_entry_set_text(GTK_ENTRY(entry13),a.date);
gtk_entry_set_text(GTK_ENTRY(entry14),a.nd_panne);
gtk_entry_set_text(GTK_ENTRY(entry15),a.etats);
}else 
{
gtk_label_set_text(GTK_LABEL(output),"l'equipement inexistant");}

}


void
on_button24_clicked                    (GtkButton       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *window1,*window8;
window8=create_window8() ;
window1=lookup_widget(objet_graphique,"window1");
gtk_widget_hide(window1);
gtk_widget_show (window8);
}


void
on_button25_clicked                    (GtkButton       *objet_graphique,
                                        gpointer         user_data)
{
char c[20];
char marq[20];
int max;
equip a;
GtkWidget *output;
FILE*f;
capteur(a);
f=fopen("equipement1.txt","r");
while(fscanf(f,"%d %s \n",&max,marq)!=EOF)
strcpy(c,marq);
fclose(f);
output=lookup_widget(objet_graphique,"label65");
gtk_label_set_text(GTK_LABEL(output),c);
}


void
on_button26_clicked                    (GtkButton       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *window1,*window8;
window1=create_window1() ;
window8=lookup_widget(objet_graphique,"window8");
gtk_widget_hide(window8);
gtk_widget_show (window1);
}


void
on_radiobutton1_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if ( gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON (togglebutton)))
{x=1;}
}


void
on_radiobutton2_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if ( gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON (togglebutton)))
{x=2;}
}


void
on_radiobutton5_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if ( gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON (togglebutton)))
{y=1;}
}


void
on_radiobutton6_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if ( gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON (togglebutton)))
{y=2;}
}

