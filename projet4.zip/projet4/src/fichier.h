#include <stdio.h>
#include <stdlib.h>
 #include <gtk/gtk.h>

typedef struct 
{
	char code_serie[20];
	char nom[20];
	char nd_panne[20];
	char date[20];
	char etats[20];
	char emplacement[20];
	
}equip;

int ajout(equip a);
void afficher(GtkWidget *liste);
void supp(char code[20]);
void modifier(equip a);
int rech(char code[]);
equip rechercher(char code[20]);
int combo2(char code[][50]);
void capteur(equip a);





