#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "fichier.h"

int ajout(equip a)
{
int test=0;

FILE *f;
f=fopen("equipement.txt","a+");
if (f!=NULL) 
{
fprintf(f," %s %s %s %s %s %s\n",a.nom,a.code_serie,a.nd_panne,a.etats,a.date,a.emplacement);
test=1;
fclose(f);	
}
return test;
}

int combo2(char code[][50])
{
int nS=0;
equip a;
FILE* f=fopen ("equipement.txt" , "r");
      
if (f!=NULL) 
	{ 
	while(fscanf(f," %s %s %s %s %s %s \n",a.nom,a.code_serie,a.nd_panne,a.etats,a.date,a.emplacement)!=EOF)
		{ 
		//if(strcmp(a.nom,"cl")==0)
			{
			strcpy (code[nS],a.code_serie);
			nS++;
			}
		}	
	}
fclose(f);
return nS;
}
