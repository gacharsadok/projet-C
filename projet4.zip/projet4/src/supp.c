#include <stdio.h>
#include "fichier.h"

void supp(char code[20]) 
{
FILE *f, *f1;
equip a;
 
f1=NULL;
  f=fopen("equipement.txt","r");

  if (f==NULL)
{
return;
} 
     while (fscanf(f,"%s %s %s %s %s %s\n",a.nom,a.code_serie,a.nd_panne,a.etats,a.date,a.emplacement)!=EOF)
{
    if (strcmp(code,a.code_serie))

 
{  f1=fopen("equipement1.txt","a+");
  fprintf(f1,"%s %s %s %s %s %s\n",a.nom,a.code_serie,a.nd_panne,a.etats,a.date,a.emplacement);;

fclose(f1);
}}
fclose(f);
 remove("equipement.txt");
 rename("equipement1.txt","equipement.txt");
}
