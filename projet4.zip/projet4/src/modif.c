#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "fichier.h"
void modifier (equip a1)
{

equip a;
FILE *f;
FILE *fa;
f=fopen("equipement.txt","r");
fa=fopen("equipement1.txt","w");
while(fscanf(f," %s %s %s %s %s %s \n",a.nom,a.code_serie,a.nd_panne,a.etats,a.date,a.emplacement)!=EOF)
 {if(strcmp(a1.code_serie,a.code_serie)!=0)      
 fprintf(fa," %s %s %s %s %s %s\n",a.nom,a.code_serie,a.nd_panne,a.etats,a.date,a.emplacement);
}
fprintf(fa,"%s %s %s %s %s %s \n",a1.nom,a1.code_serie,a1.nd_panne,a1.etats,a1.date,a1.emplacement);
fclose(f);
fclose(fa);
remove("equipement.txt");
rename("equipement1.txt","equipement.txt");
}
