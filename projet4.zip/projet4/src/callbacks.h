#include <gtk/gtk.h>


void
on_button6_clicked                     (GtkButton       *objet_graphique,
                                        gpointer         user_data);

void
on_button3_clicked                     (GtkButton       *objet_graphique,
                                        gpointer         user_data);

void
on_button1_clicked                     (GtkButton       *objet_graphique,
                                        gpointer         user_data);

void
on_button4_clicked                     (GtkButton       *objet_graphique,
                                        gpointer         user_data);

void
on_button5_clicked                     (GtkButton       *objet_graphique,
                                        gpointer         user_data);

void
on_button2_clicked                     (GtkButton       *objet_graphique,
                                        gpointer         user_data);

void
on_button21_clicked                    (GtkButton       *objet_graphique,
                                        gpointer         user_data);

void
on_button11_clicked                    (GtkButton       *objet_graphique,
                                        gpointer         user_data);

void
on_button12_clicked                    (GtkButton       *objet_graphique,
                                        gpointer         user_data);

void
on_button16_clicked                    (GtkButton       *objet_graphique,
                                        gpointer         user_data);

void
on_button15_clicked                    (GtkButton       *objet_graphique,
                                        gpointer         user_data);

void
on_button18_clicked                    (GtkButton       *objet_graphique,
                                        gpointer         user_data);

void
on_button17_clicked                    (GtkButton       *objet_graphique,
                                        gpointer         user_data);

void
on_button19_clicked                    (GtkButton       *objet_graphique,
                                        gpointer         user_data);

void
on_button20_clicked                    (GtkButton       *objet_graphique,
                                        gpointer         user_data);

void
on_button14_clicked                    (GtkButton       *objet_graphique,
                                        gpointer         user_data);

void
on_button13_clicked                    (GtkButton       *objet_graphique,
                                        gpointer         user_data);

void
on_button22_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_button23_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_button23_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_button27_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_button24_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_button25_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_button26_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_radiobutton1_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton2_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton5_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton6_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);
