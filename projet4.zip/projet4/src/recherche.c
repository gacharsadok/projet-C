#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "fichier.h"
equip rechercher(char code[20])
{equip a;
FILE*f;
f=fopen("equipement.txt","r");
while(fscanf(f," %s %d %s %s %s %s\n",a.nom,&a.code_serie,a.nd_panne,a.etats,a.date,a.emplacement)!=EOF)
{if (strcmp(code,a.code_serie)==0)
return (a);}

fclose(f);
}
