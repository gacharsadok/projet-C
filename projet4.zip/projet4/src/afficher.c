#include <gtk/gtk.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "fichier.h"
enum
{
ID=0,
NOM,
PANNE,
DATE,
ETATS,
EMPLACEMENT,
COLUMNS
};
void afficher(GtkWidget *liste)
{
equip a;
   
   GtkCellRenderer *renderer;
   GtkTreeIter iter;
   GtkListStore *store;
   GtkTreeViewColumn *column;
        int code_serie[20];
	char nom[20];
	char nd_panne[20];
	char date[20];
	char etats[20];
	char emplacement[20];
    FILE*f ;
   store=NULL;
   store=gtk_tree_view_get_model (liste);
   if (store==NULL)
   {   
   renderer= gtk_cell_renderer_text_new ();
   column= gtk_tree_view_column_new_with_attributes("Code_serie",renderer,"text",ID,NULL);
   gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);
}
   renderer= gtk_cell_renderer_text_new ();
   column= gtk_tree_view_column_new_with_attributes("Nom",renderer,"text",NOM,NULL);
   gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

   renderer= gtk_cell_renderer_text_new ();
   column= gtk_tree_view_column_new_with_attributes("Nd_panne",renderer,"text",PANNE,NULL);
   gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

   renderer= gtk_cell_renderer_text_new ();
   column= gtk_tree_view_column_new_with_attributes("Date",renderer,"text",DATE,NULL);
   gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);


   renderer= gtk_cell_renderer_text_new ();
   column= gtk_tree_view_column_new_with_attributes("Etats",renderer,"text",ETATS,NULL);
   gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

   renderer= gtk_cell_renderer_text_new ();
   column= gtk_tree_view_column_new_with_attributes("Emplacement",renderer,"text",EMPLACEMENT,NULL);
   gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);


   store=gtk_list_store_new(COLUMNS,G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING);
  
f=fopen("equipement.txt","r");
   if (f==NULL)
   {
	return;
   } 
   else
   {
      while(fscanf(f,"%s %s %s %s %s %s\n",nom,code_serie,nd_panne,etats,date,emplacement)!=EOF)
     {
      gtk_list_store_append(store, &iter);
      gtk_list_store_set(store,&iter,ID,code_serie,NOM,nom,PANNE,nd_panne,DATE,date,ETATS,etats,EMPLACEMENT,emplacement,-1);
     }

    }
  fclose(f);
 	 gtk_tree_view_set_model (GTK_TREE_VIEW (liste), GTK_TREE_MODEL (store));
 	 g_object_unref (store);
    }



