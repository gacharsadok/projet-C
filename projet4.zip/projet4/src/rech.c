#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "fichier.h"
int rech(char code[])

{ int test;
  equip a;
  FILE*f;
  f=fopen("equipement.txt","r");
   test=0;
   if (f!=NULL)
{ 
     while (fscanf(f," %s %s %s %s %s %s \n",a.nom,a.code_serie,a.nd_panne,a.etats,a.date,a.emplacement)!=EOF)
{
            if (strcmp(code,a.code_serie)==0)
{    
                 test=1;
		break;
		return 1;
}
                  }
 fclose(f);}
if (test==0)
{return 0;}
else { return 1;}
}



equip rechercher(char code[20])
{equip a;
FILE*f;
f=fopen("equipement.txt","r");
while(fscanf(f," %s %s %s %s %s %s\n",a.nom,a.code_serie,a.nd_panne,a.etats,a.date,a.emplacement)!=EOF)
{if (strcmp(code,a.code_serie)==0)
return (a);}

fclose(f);
}



void capteur(equip a)
{
FILE*f;
FILE*tmp;
int c,max;
char marq[20];
max=0;
f=fopen("equipement.txt","r");
tmp=fopen("equipement1.txt","a+");
while(fscanf(f," %s %s %s %s %s %s\n",a.nom,a.code_serie,a.nd_panne,a.etats,a.date,a.emplacement)!=EOF)

{sscanf(a.nd_panne,"%d",&c);
if(max<c)
{
max=c;
strcpy(marq,a.nom);
}

}
fprintf(tmp,"%d %s \n",max,marq);
fclose(f);
fclose(tmp);

}



